# csharp-back-to-basics
## Ref and Out Keywords in C#

https://code-maze.com/cshrap-basics-ref-out-keywords/

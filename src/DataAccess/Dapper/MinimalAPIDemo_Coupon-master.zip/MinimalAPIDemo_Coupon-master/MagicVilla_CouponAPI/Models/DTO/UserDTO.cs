﻿namespace MagicVilla_CouponAPI.Models.DTO
{
    public class UserDTO
    {
        public string ID { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
    }
}
